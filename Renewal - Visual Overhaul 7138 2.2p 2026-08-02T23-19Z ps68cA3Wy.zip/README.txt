HOW TO INSTALL: Simply drag and drop the "Renewal - Visual Overhaul" folder inside your lml folder.
________________________________________________________________________________________________________

Requirements: https://www.rdr2mods.com/downloads/rdr2/tools/76-lennys-mod-loader-rdr/
